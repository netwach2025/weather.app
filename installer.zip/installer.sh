#!/bin/bash

# --- 1. ENVIRONMENT SETUP ---
# Ensure the user has the required WebKit library for the GUI
if ! dpkg -s gir1.2-webkit-6.0 >/dev/null 2>&1; then
    echo "Preparing system dependencies (requires password)..."
    sudo apt-get update && sudo apt-get install -y gir1.2-webkit-6.0
fi

# --- 2. THE GRAPHICAL INSTALLER ---
# This runs the JS installer logic directly from this script
gjs -m /dev/stdin <<EOF
import Gtk from "gi://Gtk?version=4.0";
import Gio from "gi://Gio";
import GLib from "gi://GLib";

const SB_URL = "https://aimuwphzrmtnylouyttu.supabase.co";
const SB_KEY = "sb_publishable_kgY8DAOEKESgk1CeGIJrGQ_rsMKPthR";
const STORAGE_BASE = "https://aimuwphzrmtnylouyttu.supabase.co/storage/v1/object/public/releases";

const app = new Gtk.Application({ application_id: 'com.netwatch.installer' });

app.connect('activate', () => {
    const win = new Gtk.ApplicationWindow({ application: app });
    win.set_default_size(450, 350);
    win.set_title("NetWatch Installation Wizard");

    const box = new Gtk.Box({ orientation: Gtk.Orientation.VERTICAL, spacing: 20 });
    box.set_margin_all(40);
    box.set_valign(Gtk.Align.CENTER);

    const title = new Gtk.Label({ label: "<span size='xx-large' weight='bold' color='#2ecc71'>NetWatch</span>", use_markup: true });
    box.append(title);

    const entry = new Gtk.Entry({ placeholder_text: "Enter Account Number (NW-XXXX...)" });
    entry.set_alignment(0.5);
    box.append(entry);

    const btn = new Gtk.Button({ label: "VERIFY & DOWNLOAD" });
    btn.set_margin_top(10);
    box.append(btn);

    const status = new Gtk.Label({ label: "Ready to activate." });
    box.append(status);

    btn.connect('clicked', async () => {
        const acc = entry.get_text().trim().toUpperCase();
        if (acc.length < 4) return;

        btn.set_sensitive(false);
        status.set_label("Verifying account...");

        // Verify Account with Supabase
        const url = \`\${SB_URL}/rest/v1/licenses?account_number=eq.\${acc}\`;
        const cmd = \`curl -s -H "apikey: \${SB_KEY}" "\${url}"\`;
        const [res, stdout] = GLib.spawn_command_line_sync(cmd);
        const data = JSON.parse(new TextDecoder().decode(stdout));

        if (data.length > 0) {
            status.set_label("Account Verified! Downloading App...");
            const installDir = \`\${GLib.get_home_dir()}/.local/share/netwatch\`;
            GLib.mkdir_with_parents(installDir, 0o755);

            // Download main.js and assets from Supabase Storage
            const files = ["main.js", "balloons.jpg"];
            for (const f of files) {
                const dl = \`curl -sL -o "\${installDir}/\${f}" "\${STORAGE_BASE}/\${f}"\`;
                GLib.spawn_command_line_sync(dl);
            }

            // Save the login token
            GLib.file_set_contents(\`\${installDir}/config.json\`, JSON.stringify({ account: acc }));

            // Create Desktop Shortcut
            const desktopPath = \`\${GLib.get_home_dir()}/Desktop/NetWatch.desktop\`;
            const content = \`[Desktop Entry]\nName=NetWatch\nExec=gjs -m \${installDir}/main.js\nType=Application\nIcon=weather-clear\nTerminal=false\`;
            GLib.file_set_contents(desktopPath, content);
            GLib.spawn_command_line_sync(\`chmod +x "\${desktopPath}"\`);
            GLib.spawn_command_line_sync(\`gio set "\${desktopPath}" metadata::trusted true\`);

            status.set_label("✅ Success! App added to Desktop.");
            btn.set_label("INSTALLED");
        } else {
            status.set_label("❌ Invalid Account Number.");
            btn.set_sensitive(true);
        }
    });

    win.set_child(box);
    win.present();
});

app.run([]);
EOF
